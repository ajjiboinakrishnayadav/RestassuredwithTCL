package com.jocata.automation.testcases;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import java.io.PrintStream;
import java.io.StringWriter;
import java.util.Map;
import org.apache.log4j.Logger;
import org.apache.commons.io.output.WriterOutputStream;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.jocata.automation.codes.StatusCode;
import com.jocata.automation.reports.ExtentLogger;
import com.jocata.automation.utils.DataProviderUtils;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Issue;
import io.qameta.allure.Link;
import io.qameta.allure.Step;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;


@Epic("Latest TCLHL")
@Feature("TCLHL Customer Jounery")
public class TCLHLJouneryTestTwo {
	
	public static Logger logger = Logger.getLogger(TCLHLJouneryTestTwo.class.getName());

	public String actualResulttoken = null;
    public String tokentwo = null;
    public Object newapplicationid =null;
    public Object newapplicationidleadid=null;
    
    protected StringWriter writer;
	protected PrintStream captor;
	
    @BeforeSuite
	public void initaltest() {
     RestAssured.baseURI = "https://assistedloans.tatacapital.com/APIGateway";
         writer = new StringWriter();
		 captor = new PrintStream(new WriterOutputStream(writer), true);
		 }
	
	
   

	@Description("this is the description")
	@Test(description = "TCL HL Sample Data",dataProviderClass = DataProviderUtils.class, dataProvider = "data",priority=1)
	@Step
	public void gettcltaskboard(Map<String,String> data) {
		
		AllureLogger.logToAllure("generate token response is:::");
		
		String jsonString = "{}";

		Response response = given().
				header("content-type", "application/json").
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				body(jsonString)
				.post("/um/service/generate-token").
				then().body("status",equalTo("SUCCESS"),
						"loginType", equalTo("ldap")).
				 extract().response();
     
		System.out.println("Total response is:::" + response.asString());

		actualResulttoken = (String) (response.jsonPath().get("token") + "");
		

		System.out.println("generate token response is:::" + actualResulttoken);
		assertStatusCode(response.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), response.prettyPrint());
		logger.info("Generate Token Response Details: " + response.asString());
        logger.info("Generate toke is: "+actualResulttoken);
        
        
        
		
        AllureLogger.logToAllure("login token  response is:::");
        
        
        String jsonStringone = "{\r\n" + "\"loginToken\": \""+ actualResulttoken+"\",\r\n"
				+ "\"uname\": \"hlcre\",\r\n" + "\"upwd\": \"/Rp6JtaNekyy4CYQphd+9A==\",\r\n"
				+ "\"hsalt\": \"JrRm4gBoSMLwE7DNh2NDD9HhyfW8rlaCYNzr8mbrgtETHK+tR2z+MIcbRPR9UKrZJXSypOj9jaHBlZMrlA1NGohnFgutsnFoRX6Uip9KVpYHGcNcnTNGryVMwAkeGAsM1z3RxLbevOzFiYv+vMX0MY0JAb4vS81aGEd20kg4FH1ujuB9I/3CiAef7+f4TNvu3+b3Exngz9N+afhUR4iwdcS8lSqRIGWyubc6GxI6lFbCt3+5al8PvMajJtdayO8IdQToq1nzmBW496+5ewIa99uRHAJBRcbWPNy92cN0KiBXbraUbms8US4Mjjfu4AszWaXL351QN/RUwkk5zZFTzw==\"\r\n"
				+ "}";

		Response responseone = given().
				header("content-type", "application/json").
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				body(jsonStringone)
				.post("/um/service/login").then().body("roleName",equalTo("HL_CRE"),
						"productName", equalTo("HOMELOAN")).
				log().all().extract().response();

		String jsonstring = responseone.asString();
		System.out.println("login token response is login:::" + responseone.asString());

		tokentwo = JsonPath.from(jsonstring).get("token");
		

		System.out.println("login token is :::-------" + tokentwo);
		assertStatusCode(responseone.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), responseone.prettyPrint());
		
		
		
		AllureLogger.logToAllure("Taskboard  response is:::");
		
		
		String jsonStringtwo = "{\"eventDetails\":\"Taskboard\"}";
		Response responsetwo = given().
				header("content-type", "application/json")
				.header("Authorization", "Bearer " + tokentwo).
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				body(jsonStringtwo).
				post("/dlp/audit/save-user-navigation")
				.then().body("eventDetails",equalTo("Taskboard"))
						.log().all().extract().response();
		//String jsonstring = response.asString();

		System.out.println("save usernavigation response is :::" + responsetwo.asString());
		assertStatusCode(responsetwo.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), responsetwo.prettyPrint());
		
		
		
		AllureLogger.logToAllure("get user products roles map is:::");
		
		
		Response responsethree = given().
				 header("content-type", "application/json")
				.header("Authorization", "Bearer " + tokentwo).
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				get("/um/service/user/get-user-products-roles-map")
				.then().body("[0].roles[0].roleName",equalTo("HL_CRE"),
						"[0].productName", equalTo("HOME LOAN")).
				log().all().extract().response();
		String jsonstringthree = responsethree.asString();

		System.out.println("get user products roles map :::" + responsethree.asString());
		assertStatusCode(responsethree.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), responsethree.prettyPrint());
		
		
		
		AllureLogger.logToAllure(" tcl taskboard:::");
		
		System.out.println("user id ::::::::::::::"+data.get("userId"));
		System.out.println("roleId id ::::::::::::::"+data.get("roleId"));

		String jsonStringfour = "{\"userId\":"+data.get("userId")+",\"roleId\":"+data.get("roleId")+",\"type\":\"Assigned\"}";
		
		Response responsefour = given().
				 header("content-type", "application/json")
				.header("Authorization", "Bearer " + tokentwo).
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				body(jsonStringfour).
				post("/dlphl/get-tcl-taskboard")
				.then().body("status",equalTo("SUCCESS"),
						"record.data[0].productTypeCode", equalTo("HOMELOAN")).
				log().all().extract().response();
		String jsonstringfour = responsefour.asString();

		System.out.println("get tcl taskboard :::" + responsefour.asString());
		assertStatusCode(responsefour.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), responsefour.prettyPrint());

	}
	
	
	
	
	
	
	
	
	     @Step
	    public void assertStatusCode(int actualStatusCode, StatusCode statusCode){
	        assertThat(actualStatusCode, equalTo(statusCode.code));
	    }

}
