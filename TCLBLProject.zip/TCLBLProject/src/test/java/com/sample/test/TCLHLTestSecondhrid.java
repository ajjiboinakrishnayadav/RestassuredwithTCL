package com.sample.test;

import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.sample.utils.ExcelReader;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class TCLHLTestSecondhrid extends BaseClass {

	@Test
	public void sampletest() throws Exception {

		List<Map<String, String>> latestdaa = ExcelReader.readalldata();

		for (Map<String, String> map : latestdaa) {

			
			
			ExtentTest test1 = extent.createTest("TCL HL Jounery");
			
			

			driver.get("https://assistedloans.tatacapital.com/assisted/home");
			test1.log(Status.PASS, "Navigate to https://assistedloans.tatacapital.com/assisted/home");
			test1.log(Status.INFO, "Test  started");

			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

			WebDriverWait wait = new WebDriverWait(driver, 30);

			MobileElement username = (MobileElement) driver.findElementById("mat-input-0");
			username.sendKeys(map.get("username"));
			test1.log(Status.INFO, "enter the username as"+map.get("username"));
			Thread.sleep(3000);
			MobileElement password = (MobileElement) driver.findElementById("mat-input-1");
			password.sendKeys(map.get("password"));
			test1.log(Status.INFO, "enter the password as"+map.get("password"));
			driver.hideKeyboard();

			WebElement login_button = driver.findElement(By.className("android.widget.Button"));

			wait.until(ExpectedConditions.visibilityOf(login_button));

			login_button.click();

			driver.findElementByClassName("android.widget.Button").click();
			test1.log(Status.INFO, "click on login button");
			

			Thread.sleep(6000);
			driver.findElementByXPath("//android.widget.Button[@text='CREATE APPLICATION']").click();
			test1.log(Status.INFO, "click on create application");
			Thread.sleep(8000);

			driver.findElementByXPath("//android.widget.ListView[@text='Branch *']").click();
			
			test1.log(Status.INFO, "select the branch name");

			driver.findElementByXPath("//android.view.View[@text='" + map.get("branch") + "']").click();
			test1.log(Status.INFO, "select the branch name as "+map.get("branch"));
			Thread.sleep(1000);

			driver.findElementByXPath("//android.widget.ListView[@text='Sourcing Channel *']").click();
			test1.log(Status.INFO, "select the Sourcing Channel");

			driver.findElementByXPath("//android.view.View[@text='" + map.get("sourcingchannel") + "']").click();
			test1.log(Status.INFO, "select the sourcing channel as "+map.get("sourcingchannel"));
			Thread.sleep(1000);

			driver.findElementByXPath("//android.widget.ListView[@text='SM Name *']").click();

			driver.findElementByXPath("//android.view.View[@text='" + map.get("smname") + ", in list, item 2 of 2']")
					.click();
			
			test1.log(Status.INFO, "select the sm name as "+map.get("smname"));

			driver.findElementByXPath("//android.widget.ListView[@text='Product Type *']").click();

			driver.findElementByXPath("//android.view.View[@text='" + map.get("producttype") + "']").click();
			
			test1.log(Status.INFO, "select the sm name as "+map.get("producttype"));

			driver.findElementByXPath("//android.widget.ListView[@text='Alternate Channel Mode *']").click();

			driver.findElementByXPath("//android.view.View[@text='" + map.get("alternatechannelmode") + "']").click();
			
			test1.log(Status.INFO, "select the sm name as "+map.get("alternatechannelmode"));

			driver.findElement(By.id("mat-input-2")).sendKeys(map.get("pannumber"));

			driver.findElement(By.id("mat-input-3")).sendKeys(map.get("pannumber"));
			
			test1.log(Status.INFO, "enter the pannumer as "+map.get("pannumber"));

			driver.hideKeyboard();

			driver.findElement(By.id("mat-input-3")).sendKeys(map.get("phonenumber"));
			
			test1.log(Status.INFO, "enter the phone as "+map.get("phonenumber"));

			driver.hideKeyboard();

			Thread.sleep(3000);

			driver.navigate().to("https://assistedloans.tatacapital.com/assisted/home");

			Thread.sleep(6000);

			System.out.println("STOP the execution");

		}

	}

}
