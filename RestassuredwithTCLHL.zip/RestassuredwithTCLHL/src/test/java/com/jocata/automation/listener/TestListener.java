package com.jocata.automation.listener;

import java.io.IOException;
import java.util.Arrays;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.jocata.automation.reports.ExtentLogger;
import com.jocata.automation.reports.ExtentReport;

public class TestListener  implements ITestListener, ISuiteListener{

	public void onStart(ISuite suite) {
		// TODO Auto-generated method stub
		ExtentReport.initReports();
		
	}

	public void onFinish(ISuite suite) {
		// TODO Auto-generated method stub
		try {
			ExtentReport.tearDownReports();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	public void onTestStart(ITestResult result) {
		// TODO Auto-generated method stub
		ExtentReport.createTest(result.getMethod().getDescription());
		ExtentLogger.pass(result.getMethod().getDescription()+ " is started successfully");
		
	}

	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		ExtentLogger.pass(result.getName()+ " is passed");
	}

	public void onTestFailure(ITestResult result) {
		// TODO Auto-generated method stub
		ExtentLogger.fail(result.getThrowable().getMessage());
		ExtentLogger.logStackTraceInfoInExtentReport(Arrays.toString(result.getThrowable().getStackTrace()));
		ExtentLogger.fail(result.getName()+ " is failed miserably");
		
	}

	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		ExtentLogger.skip(result.getName()+ " is skipped");
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

}
