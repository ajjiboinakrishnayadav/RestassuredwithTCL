package com.sample.test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;

public class SampleTest2 {

	AppiumDriverLocalService service;
	AppiumDriver<MobileElement> driver;
	
	
	
	//public static WebDriver driver;

	public void setUP() throws MalformedURLException {
		service = AppiumDriverLocalService.buildDefaultService();
		service.start();
		System.out.println("Server is started.....");

		DesiredCapabilities capabilities = new DesiredCapabilities();

		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Device");
		capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "com.android.chrome");
		capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, "com.google.android.apps.chrome.Main");
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "9");
		capabilities.setCapability("udid", "VG8T4PRO5D7HBY8H");
		capabilities.setCapability("noReset", true);
		
		//capabilities.setCapability(AndroidMobileCapabilityType.CHROMEDRIVER_USE_SYSTEM_EXECUTABLE, "D:\\seleniumasos\\chromedriver.exe");
		
		//capabilities.setCapability("browserName", "Chrome");
		//capabilities.setCapability(CapabilityType.BROWSER_NAME, "Chrome");
		
		//System.setProperty("webdriver.chrome.driver","D:\\seleniumasos\\chromedriver_win32");

		capabilities.setCapability("chromedriverExecutable", "D:\\Latestchrome\\MM\\chromedriver.exe");
		
		URL url = new URL("http://0.0.0.0:4723/wd/hub");

		//driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
		driver = new AppiumDriver<MobileElement>(url, capabilities);

		driver.get("http://www.google.com");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	public void searchKeyword() throws InterruptedException {
		

		//driver.findElementByName("q").sendKeys("appium");
		
		driver.findElementByClassName("android.widget.EditText").sendKeys("appium");
		
		//driver.findElementByXPath("//android.view.View[@content-desc=\"IMAGES\"]/android.widget.TextView").click();
		Thread.sleep(5000);
		//driver.findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.webkit.WebView/android.view.View[1]/android.view.View[3]/android.view.View[2]/android.view.View[1]/android.widget.EditText").sendKeys("appium");
		//driver.findElement(By.xpath("//input[@title='Search']")).sendKeys("appium");
		//Thread.sleep(5000);

	}

	public void tearDown() {
		driver.quit();
		service.stop();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		// TODO Auto-generated method stub
		SampleTest2 obj = new SampleTest2();
		obj.setUP();
		obj.searchKeyword();
		obj.tearDown();

	}

}
