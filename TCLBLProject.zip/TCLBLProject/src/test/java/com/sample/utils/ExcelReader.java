package com.sample.utils;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

	public static final String FILEPATH = "./DataFiles/TCLHLTEST.xlsx";

	private static FileInputStream fis;
	private static XSSFWorkbook workbook;
	private static XSSFSheet sheet;
	private static XSSFRow row;

	
public static void loadExcelData() throws Exception {
		File file = new File(FILEPATH);
		fis = new FileInputStream(file);
		workbook = new XSSFWorkbook(fis);
		sheet = workbook.getSheet("TestData");
		fis.close();
	}

	public static List<Map<String, String>> readalldata() throws Exception {

		if (sheet == null) {
			loadExcelData();
		}

		List<Map<String, String>> maplists = new ArrayList<>();

		int rows = sheet.getLastRowNum();

		row = sheet.getRow(0);

		for (int j = 1; j < row.getLastCellNum(); j++) {

			Map<String, String> mymap = new HashMap<String, String>();

			for (int i = 1; i < rows+1; i++) {

				Row r = CellUtil.getRow(i, sheet);

				String key = CellUtil.getCell(r, 0).getStringCellValue();

				String value = CellUtil.getCell(r, j).getStringCellValue();

				mymap.put(key, value);
			}

			maplists.add(mymap);

		}

		return maplists;

	}
	
	
//	public static List<Map<String, String>> retriveData(List<Map<String,String>> readalldaa) {
//		
//		
//		for (Map<String, String> map : readalldaa) {
//			
//			map.get("UserName");
//			
//			System.out.println(map.get("UserName"));
//			System.out.println(map.get("Password"));
//		}
//		return readalldaa;
//	}

}
