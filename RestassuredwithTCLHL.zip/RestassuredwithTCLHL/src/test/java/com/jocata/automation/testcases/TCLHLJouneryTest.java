package com.jocata.automation.testcases;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import java.io.PrintStream;
import java.io.StringWriter;
import java.util.Map;
import org.apache.log4j.Logger;
import org.apache.commons.io.output.WriterOutputStream;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.jocata.automation.codes.StatusCode;
import com.jocata.automation.reports.ExtentLogger;
import com.jocata.automation.utils.DataProviderUtils;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Issue;
import io.qameta.allure.Link;
import io.qameta.allure.Step;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;


@Epic("Latest TCLHL")
@Feature("TCLHL Customer Jounery")
public class TCLHLJouneryTest {
	
	public static Logger logger = Logger.getLogger(TCLHLJouneryTest.class.getName());

	public String actualResulttoken = null;
    public String tokentwo = null;
    public Object newapplicationid = null;
    public Object newapplicationidleadid = null;
    
    protected StringWriter writer;
	protected PrintStream captor;
	
    @BeforeSuite
	public void initaltest() {
     RestAssured.baseURI = "https://assistedloans.tatacapital.com/APIGateway";
         writer = new StringWriter();
		 captor = new PrintStream(new WriterOutputStream(writer), true);

	}
	
	
    @Link("https://assistedloans.tatacapital.com")
    @Link(name = "allure", type = "mylink")
    @Step
    @Description("this is the description")
    @Test(description = "TCLHL Generate Token",priority=1)
	public void generatetoken() {

		String jsonString = "{}";

		Response response = given().
				header("content-type", "application/json").
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				body(jsonString)
				.post("/um/service/generate-token").
				then().body("status",equalTo("SUCCESS"),
						"loginType", equalTo("ldap")).
				 extract().response();
     
		System.out.println("Total response is:::" + response.asString());

		actualResulttoken = (String) (response.jsonPath().get("token") + "");
		

		System.out.println("generate token response is:::" + actualResulttoken);
		assertStatusCode(response.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), response.prettyPrint());
		logger.info("Generate Token Response Details: " + response.asString());
        logger.info("Generate toke is: "+actualResulttoken);

	}

	@Description("this is the description")
	@Test(description = "TCLHL Login Token",priority=2)
	@Step
	public void logintoken() {
		
		

		String jsonString = "{\r\n" + "\"loginToken\": \""+ actualResulttoken+"\",\r\n"
				+ "\"uname\": \"hlcre\",\r\n" + "\"upwd\": \"/Rp6JtaNekyy4CYQphd+9A==\",\r\n"
				+ "\"hsalt\": \"JrRm4gBoSMLwE7DNh2NDD9HhyfW8rlaCYNzr8mbrgtETHK+tR2z+MIcbRPR9UKrZJXSypOj9jaHBlZMrlA1NGohnFgutsnFoRX6Uip9KVpYHGcNcnTNGryVMwAkeGAsM1z3RxLbevOzFiYv+vMX0MY0JAb4vS81aGEd20kg4FH1ujuB9I/3CiAef7+f4TNvu3+b3Exngz9N+afhUR4iwdcS8lSqRIGWyubc6GxI6lFbCt3+5al8PvMajJtdayO8IdQToq1nzmBW496+5ewIa99uRHAJBRcbWPNy92cN0KiBXbraUbms8US4Mjjfu4AszWaXL351QN/RUwkk5zZFTzw==\"\r\n"
				+ "}";

		Response response = given().
				header("content-type", "application/json").
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				body(jsonString)
				.post("/um/service/login").then().body("roleName",equalTo("HL_CRE"),
						"productName", equalTo("HOMELOAN")).
				log().all().extract().response();

		String jsonstring = response.asString();
		System.out.println("login token response is login:::" + response.asString());

		tokentwo = JsonPath.from(jsonstring).get("token");
		

		System.out.println("login token is :::-------" + tokentwo);
		assertStatusCode(response.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), response.prettyPrint());
	}
	
	@Description("this is the description")
	@Test(description = "save user navigation",priority=3)
	@Step
	public void saveusernavigation() {

		String jsonString = "{\"eventDetails\":\"Taskboard\"}";
		Response response = given().
				header("content-type", "application/json")
				.header("Authorization", "Bearer " + tokentwo).
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				body(jsonString).
				post("/dlp/audit/save-user-navigation")
				.then().body("eventDetails",equalTo("Taskboard"))
						.log().all().extract().response();
		String jsonstring = response.asString();

		System.out.println("save usernavigation response is :::" + response.asString());
		assertStatusCode(response.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), response.prettyPrint());

	}
	
	
	@Description("this is the description")
	@Test(description = "get user products roles map",priority=4)
	@Step
	public void tgetuserproductsrolesmap() {

		
		Response response = given().
				 header("content-type", "application/json")
				.header("Authorization", "Bearer " + tokentwo).
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				get("/um/service/user/get-user-products-roles-map")
				.then().body("[0].roles[0].roleName",equalTo("HL_CRE"),
						"[0].productName", equalTo("HOME LOAN")).
				log().all().extract().response();
		String jsonstring = response.asString();

		System.out.println("get user products roles map :::" + response.asString());
		assertStatusCode(response.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), response.prettyPrint());

	}
	
	@Description("this is the description")
	@Test(description = "get tcl taskboard",dataProviderClass = DataProviderUtils.class, dataProvider = "data",priority=5)
	@Step
	public void gettcltaskboard(Map<String,String> data) {
		
		System.out.println("user id ::::::::::::::"+data.get("userId"));
		System.out.println("roleId id ::::::::::::::"+data.get("roleId"));

		String jsonString = "{\"userId\":"+data.get("userId")+",\"roleId\":"+data.get("roleId")+",\"type\":\"Assigned\"}";
		
		Response response = given().
				 header("content-type", "application/json")
				.header("Authorization", "Bearer " + tokentwo).
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				body(jsonString).
				post("/dlphl/get-tcl-taskboard")
				.then().body("status",equalTo("SUCCESS"),
						"record.data[0].productTypeCode", equalTo("HOMELOAN")).
				log().all().extract().response();
		String jsonstring = response.asString();

		System.out.println("get tcl taskboard :::" + response.asString());
		assertStatusCode(response.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), response.prettyPrint());

	}
	
	
	@Description("this is the description")
	@Test(description = "saveNewHLApplication",priority=6)
	@Step
	public void saveNewHLApplication() {

		String jsonString = "{\"provider\":\"Direct\",\"dsarole\":\"\",\"branchName\":48043,\"smName\":368,\"creName\":null,\"dsaName\":null,\"typeofjourney\":null,\"mobile\":9022415493,\"panNo\":\"AAAPA0263B\",\"productType\":47976,\"existingCustomer\":\"\",\"dob\":\"\",\"idType\":\"\",\"idNumber\":\"\",\"loanAmount\":null,\"tenor\":null,\"sourcingChannel\":48260,\"search\":\"\",\"gstin\":null,\"state\":0,\"city\":null,\"program\":null,\"applicationId\":null,\"firstName\":null,\"middleName\":null,\"lastName\":null,\"entityLegalNameOrFullName\":null,\"loanApplicantType\":null,\"productDisplayName\":null,\"applicantDisplayName\":null,\"product\":null,\"cityCode\":null,\"fullName\":null,\"genericScreenId\":null,\"ucic\":null,\"webtopEndpoint\":null,\"customerName\":\"\",\"offerStatus\":false,\"offerId\":null,\"tenure\":null,\"campaignName\":null,\"roleId\":8}";
		
		
		Response response = given().
				 header("content-type", "application/json")
				.header("Authorization", "Bearer " + tokentwo).
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				body(jsonString).
				post("/dlphl/hl/saveNewHLApplication")
				.then().body("status",equalTo("SUCCESS"),
						"entity.fullName", equalTo("SANJAY AGARWAL")).
				log().all().extract().response();
		String jsonstring = response.asString();

		System.out.println("saveNewHLApplication :::" + response.asString());
		assertStatusCode(response.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), response.prettyPrint());
		
		 newapplicationid = JsonPath.from(jsonstring).get("entity.applicationId");
		 System.out.println("New application id is :::-------" +newapplicationid);

	}
	
	
	@Description("this is the description")
	@Test(description = "execute-application",priority=7)
	@Step
	public void executeapplication() {

		String jsonString = "{\r\n" + 
				"    \"appID\": \""+newapplicationid+"\",\r\n" + 
				"    \"product\": \"43\",\r\n" + 
				"    \"roleID\": \"8\",\r\n" + 
				"    \"appUserID\": \"17\",\r\n" + 
				"    \"userId\": \"17\"\r\n" + 
				"}";
		
		Response response = given().
				 header("content-type", "application/json")
				.header("Authorization", "Bearer " + tokentwo).
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				body(jsonString).
				post("/wfms/execute-application")
				.then().body("body.status",equalTo("SUCCESS"),
						"statusCode", equalTo("OK")).
				log().all().extract().response();
		String jsonstring = response.asString();

		System.out.println("execute-application :::" + response.asString());
		assertStatusCode(response.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), response.prettyPrint());

	}
	
	
	@Description("this is the description")
	@Test(description = "Application Overview save-user-navigation",priority=8)
	@Step
	public void saveusernavigationapplicationoverview() {

		String jsonString = "{\"eventDetails\":\"Application Overview\",\"appPackageId\":"+newapplicationid+"}";
		
		Response response = given().
				 header("content-type", "application/json")
				.header("Authorization", "Bearer " + tokentwo).
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				body(jsonString).
				post("/dlp/audit/save-user-navigation")
				.then().body("eventDetails",equalTo("Application Overview")).
				log().all().extract().response();
		String jsonstring = response.asString();

		System.out.println("Application Overview save-user-navigation :::" + response.asString());
		assertStatusCode(response.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), response.prettyPrint());

	}
	
	
	
	
	@Description("this is the description")
	@Test(description = "leadId",priority=9)
	@Step
	public void dmsdocumentlist() {

		String jsonString = "{\"appPackageId\":"+newapplicationid+"}";
		
		Response response = given().
				 header("content-type", "application/json")
				.header("Authorization", "Bearer " + tokentwo).
				filter(new AllureRestAssured()).
				filter(new RequestLoggingFilter(captor)).
				body(jsonString).
				post("/dlphl/dms/documentlist/documentlist")
				.then().body("status.statusCode",equalTo("200")).
				log().all().extract().response();
		String jsonstring = response.asString();

		System.out.println("leadId response is :::" + response.asString());
		assertStatusCode(response.statusCode(), StatusCode.CODE_200);
		ExtentLogger.logRequestAndResponseInReport(writer.toString(), response.prettyPrint());
		
		
		 newapplicationidleadid = JsonPath.from(jsonstring).get("leadId");
		 System.out.println("leadId is :::" +newapplicationidleadid);
	}
	
	
	
	
	
	     @Step
	    public void assertStatusCode(int actualStatusCode, StatusCode statusCode){
	        assertThat(actualStatusCode, equalTo(statusCode.code));
	    }

}
