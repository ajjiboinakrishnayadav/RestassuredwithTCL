package com.sample.test;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.sample.reports.ExtentReportsDemo;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class BaseClass extends ExtentReportsDemo {
	

	AppiumDriver driver;

	@BeforeClass
	public void setUp() throws MalformedURLException, Exception {
		DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
		desiredCapabilities.setCapability("platformVersion", "9");
		desiredCapabilities.setCapability("deviceName", "Android Device");
		desiredCapabilities.setCapability("platformName", "Android");
		desiredCapabilities.setCapability("appPackage", "com.android.chrome");
		desiredCapabilities.setCapability("appActivity", "com.google.android.apps.chrome.Main");
		desiredCapabilities.setCapability("noReset", "true");
		desiredCapabilities.setCapability("udid", "VG8T4PRO5D7HBY8H");

		URL remoteUrl = new URL("http://localhost:4723/wd/hub");

		driver = new AndroidDriver(remoteUrl, desiredCapabilities);

	}
	
	@AfterClass
	public void tearDown() {
		driver.quit();
	}

}
