package com.sample.test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class TCLHLTestSecond {

	// public static AndroidDriver<MobileElement> driver;

	AppiumDriver driver;

	@BeforeClass
	public void setUp() throws MalformedURLException, Exception {
		DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
		desiredCapabilities.setCapability("platformVersion", "9");
		desiredCapabilities.setCapability("deviceName", "Android Device");
		desiredCapabilities.setCapability("platformName", "Android");
		desiredCapabilities.setCapability("appPackage", "com.android.chrome");
		desiredCapabilities.setCapability("appActivity", "com.google.android.apps.chrome.Main");
		desiredCapabilities.setCapability("noReset", "true");
		desiredCapabilities.setCapability("udid", "VG8T4PRO5D7HBY8H");

		URL remoteUrl = new URL("http://localhost:4723/wd/hub");

		driver = new AndroidDriver(remoteUrl, desiredCapabilities);

		driver.get("https://assistedloans.tatacapital.com/assisted/home");
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

		Thread.sleep(4000);
	}

	@Test
	public void sampleTest() throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, 30);

		MobileElement username = (MobileElement) driver.findElementById("mat-input-0");
		username.sendKeys("hlcre");
		Thread.sleep(3000);
		MobileElement password = (MobileElement) driver.findElementById("mat-input-1");
		password.sendKeys("Jocata@111");

		Thread.sleep(3000);

		driver.hideKeyboard();

		Thread.sleep(3000);

		WebElement login_button = driver.findElement(By.className("android.widget.Button"));

		wait.until(ExpectedConditions.visibilityOf(login_button));

		login_button.click();

		Thread.sleep(4000);
		driver.findElementByClassName("android.widget.Button").click();
		Thread.sleep(6000);

		driver.findElementByXPath("//android.widget.Button[@text='CREATE APPLICATION']").click();

		Thread.sleep(5000);

		driver.findElementByXPath("//android.widget.ListView[@text='Branch *']").click();

		Thread.sleep(4000);
		driver.findElementByXPath("//android.view.View[@text='0202 - BARODA ALKA, in list, item 2 of 14']").click();

		Thread.sleep(3000);

		driver.findElementByXPath("//android.widget.ListView[@text='Sourcing Channel *']").click();

		Thread.sleep(4000);
		driver.findElementByXPath("//android.view.View[@text='ALTERNATE CHANNEL, in list, item 2 of 7']").click();

		Thread.sleep(3000);

		driver.findElementByXPath("//android.widget.ListView[@text='SM Name *']").click();

		Thread.sleep(4000);
		driver.findElementByXPath("//android.view.View[@text='hlsm M, in list, item 2 of 2']").click();

		Thread.sleep(3000);

		driver.findElementByXPath("//android.widget.ListView[@text='Product Type *']").click();

		Thread.sleep(4000);
		driver.findElementByXPath("//android.view.View[@text='INSURANCE LOAN, in list, item 2 of 4']").click();

		Thread.sleep(3000);

		driver.findElementByXPath("//android.widget.ListView[@text='Alternate Channel Mode *']").click();
		Thread.sleep(4000);
		driver.findElementByXPath("//android.view.View[@text='CF-Retail, in list, item 2 of 4']").click();

		Thread.sleep(6000);
		
		
		driver.findElement(By.id("mat-input-2")).sendKeys("AWFPA9541F");
		Thread.sleep(6000);
		driver.findElement(By.id("mat-input-3")).sendKeys("AWFPA9541F");
		Thread.sleep(6000);
		driver.hideKeyboard();
	
		Thread.sleep(6000);
		driver.findElement(By.id("mat-input-3")).sendKeys("8106212194");
		Thread.sleep(6000);
		driver.hideKeyboard();
		Thread.sleep(6000);
		System.out.println("STOP");

	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}
